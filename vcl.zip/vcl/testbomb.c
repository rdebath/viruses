/* C Logic bomb test module for Virus Creation Laboratory
   (C) 1992 Nowhere Man and [NuKE] WaReZ
   Written by Nowhere Man

   Link this with the .OBJ file of your logic bomb for testing purposes.
*/

#include <stdio.h>

extern void logic_bomb(void);

int main(void)
{
	register int i;

	logic_bomb();

	for (i = 1; i <= 10; i++)
		printf("Hello, world! (#%d)\n", i);

	return(0);
}